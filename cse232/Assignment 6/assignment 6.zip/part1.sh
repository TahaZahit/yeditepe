#!/bin/bash

for a in `seq 1 $2`; 
do
	mkdir `head -$a $1 | tail -1`	
done

tail -`expr $2 - 1` $1 > 1.txt

for (( a = 2; a < $2; a++ )) 
do
	tail -`expr $2 - $a` `expr $a - 1`.txt > $a.txt	
done


