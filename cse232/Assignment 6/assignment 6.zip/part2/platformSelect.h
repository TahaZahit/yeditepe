#include "platforms.h"
#if (DESKTOP == 1) 
#include "desktop.h"
#elif (MOBILE == 1)
#include "mobile.h"
#else
#define PLATFORM "platformUndefined"
#endif
