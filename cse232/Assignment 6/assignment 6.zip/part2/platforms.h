#define DESKTOP 1
#define MOBILE 0
