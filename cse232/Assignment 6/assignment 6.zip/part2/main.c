#include "platformSelect.h"
#include<stdio.h>
int main() {
	printf("Platform is %s\n",PLATFORM);
	return 0;
}
