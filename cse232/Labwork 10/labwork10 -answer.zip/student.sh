#!/bin/bash

if [ $# -ne 3 ]
then 
	echo "Error missing argument."
else
	awk -f awk.awk $1 > $3
	awk -f awk.awk $2 >> $3
	cat $3
fi
